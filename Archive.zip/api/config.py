from app import *

application.config['SQLALCHEMY_DATABASE_URI'] = "postgresql://josh:josh12345678@aa169kxdyt8mkhx.ciy2qyqwn3ta.us-west-1.rds.amazonaws.com/api"